import json
import boto3
import os

cloud_front = boto3.client("cloudfront")
bucket = os.environ["BUCKET_NAME"]
invalidation_paths = os.environ["INVALIDATION_PATHS"]
cloud_front_distribution_id = os.environ["CLOUDFRONT_DISTRIBUTION_ID"]

def lambda_handler(event, context):
    # Extract information from S3 event
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']

    # Specify the CloudFront distribution ID
    distribution_id = cloud_front_distribution_id

    # Specify the object path to be invalidated (e.g., '/*' to invalidate all)
    object_paths = os.environ["INVALIDATION_PATHS"].split(",")

    try:
        # Create CloudFront invalidation
        cloud_front.create_invalidation(
            DistributionId=distribution_id,
            InvalidationBatch={
                'Paths': {
                    'Quantity': len(object_paths),
                    'Items': object_paths,
                },
                'CallerReference': str(hash(key)),  # You can use a different reference based on your needs
            }
        )
    except Exception as e:
        print(f"Error: {e}")
        raise e